Lampa: добавьте в IPTV плейлист URL https://ВАШ-ДОМЕН/integrations/lampa/playlist.php
JSON feed: https://ВАШ-ДОМЕН/integrations/lampa/channels.php
Экспортируются только одобренные бесплатные каналы с активным прямым HTTPS MP4/HLS источником.
