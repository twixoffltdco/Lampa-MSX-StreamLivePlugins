<?php
require_once dirname(__DIR__).'/shared/api.php'; header('Content-Type: application/vnd.apple.mpegurl; charset=utf-8'); header('Cache-Control: no-store, private');
echo "#EXTM3U\n";
foreach(sl_external_channels() as $c){$logo=str_replace(["\r","\n",'"'],'',$c['logo']);$title=str_replace(["\r","\n",','],[' ',' ',' '],$c['title']);echo '#EXTINF:-1 tvg-id="'.(int)$c['id'].'" tvg-name="'.htmlspecialchars($title,ENT_QUOTES,'UTF-8').'" tvg-logo="'.$logo.'",'.$title."\n".$c['stream']."\n";}
