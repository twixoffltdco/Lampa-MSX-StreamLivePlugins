<?php
require_once dirname(__DIR__).'/shared/api.php'; sl_external_json_headers();
echo json_encode(['name'=>'StreamLive','updated'=>gmdate('c'),'items'=>sl_external_channels()],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
