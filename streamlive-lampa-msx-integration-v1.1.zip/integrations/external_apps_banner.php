<?php
// Add `require_once __DIR__ . '/../integrations/external_apps_banner.php';` before </body> in includes/footer.php.
// Check the public route, not only SCRIPT_NAME: front controllers often keep
// SCRIPT_NAME=/index.php while REQUEST_URI contains /platforma/....
$__slRouteCandidates = [
    (string)($_SERVER['REQUEST_URI'] ?? ''),
    (string)($_SERVER['PATH_INFO'] ?? ''),
    (string)($_SERVER['PHP_SELF'] ?? ''),
    (string)($_SERVER['SCRIPT_NAME'] ?? ''),
];
$__slIsPlatforma = false;
foreach ($__slRouteCandidates as $__slCandidate) {
    $__slPath = (string)(parse_url($__slCandidate, PHP_URL_PATH) ?? $__slCandidate);
    if (preg_match('~(?:^|/)platforma(?:/|$)~i', $__slPath)) {
        $__slIsPlatforma = true;
        break;
    }
}
$__slNative = $__slIsPlatforma || !empty($_COOKIE['streamlive_native_app']);
if (!$__slNative): ?>
<div id="sl-external-apps" class="sl-ext-overlay" hidden role="dialog" aria-modal="true" aria-labelledby="sl-ext-title">
 <div class="sl-ext-card"><button type="button" class="sl-ext-close" aria-label="Закрыть">×</button>
  <div class="sl-ext-kicker">STREAMLIVE · НОВЫЕ ВОЗМОЖНОСТИ</div>
  <h2 id="sl-ext-title">Мы появились в Lampa и Media Station X!</h2>
  <p>Смотрите доступные прямые эфиры StreamLive прямо в совместимых медиаприложениях.</p>
  <button type="button" class="sl-ext-ok">Понятно</button>
 </div>
</div>
<style>
.sl-ext-overlay{position:fixed;inset:0;z-index:2147483000;background:rgba(3,8,20,.82);display:flex;align-items:center;justify-content:center;padding:22px;backdrop-filter:blur(7px)}
.sl-ext-overlay[hidden]{display:none}.sl-ext-card{position:relative;width:min(560px,100%);padding:38px 30px 30px;border-radius:24px;background:linear-gradient(145deg,#17243d,#0b1220);border:1px solid #344766;color:#f4f7ff;text-align:center;box-shadow:0 25px 90px #0009;font-family:system-ui,sans-serif}
.sl-ext-kicker{font-size:11px;letter-spacing:.16em;color:#83b9ff;font-weight:800}.sl-ext-card h2{font-size:clamp(24px,5vw,34px);line-height:1.15;margin:15px 0}.sl-ext-card p{color:#c2cde0;line-height:1.55}.sl-ext-close{position:absolute;right:14px;top:10px;border:0;background:transparent;color:#dce7f7;font-size:30px;cursor:pointer}.sl-ext-ok{margin-top:16px;border:0;border-radius:999px;padding:12px 28px;background:#3b82f6;color:white;font-weight:700;cursor:pointer}
</style>
<script>
(()=>{const key='sl_ext_apps_hide_until',el=document.getElementById('sl-external-apps');if(!el)return;let until=0;try{until=Number(localStorage.getItem(key)||0)}catch(e){}if(Date.now()<until)return;el.hidden=false;const close=()=>{try{localStorage.setItem(key,String(Date.now()+30*24*60*60*1000))}catch(e){}el.hidden=true};el.querySelectorAll('.sl-ext-close,.sl-ext-ok').forEach(b=>b.addEventListener('click',close));el.addEventListener('click',e=>{if(e.target===el)close()})})();
</script>
<?php endif; ?>
