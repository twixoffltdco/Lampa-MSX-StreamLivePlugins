<?php
require_once dirname(__DIR__).'/shared/api.php'; sl_external_json_headers(); $items=[];
foreach(sl_external_channels() as $c){$items[]=['title'=>$c['title'],'image'=>$c['logo'],'description'=>$c['description'],'action'=>$c['stream'],'type'=>'video'];}
echo json_encode(['type'=>'list','headline'=>'StreamLive · Прямые эфиры','template'=>'poster','items'=>$items],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
