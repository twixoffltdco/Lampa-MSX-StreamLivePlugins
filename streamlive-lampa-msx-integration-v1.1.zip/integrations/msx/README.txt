Media Station X portal entry: https://ВАШ-ДОМЕН/integrations/msx/start.json
Fallback JSON page: https://ВАШ-ДОМЕН/integrations/msx/portal.php
Схема MSX зависит от версии клиента/прошивки — проверить на устройстве до публичного запуска.
