<?php
/** Public-only feed. Paid/locked channels are never exported. */
require_once dirname(__DIR__, 2) . '/includes/functions.php';
require_once dirname(__DIR__, 2) . '/includes/auth.php';
require_once dirname(__DIR__, 2) . '/includes/paid_access.php';
function sl_external_channels(): array {
  paid_ensure_schema();
  $rows = db()->query("SELECT c.* FROM channels c WHERE c.status='approved' AND COALESCE(c.paid_content,0)=0 ORDER BY c.views DESC, c.created_at DESC LIMIT 250")->fetchAll(PDO::FETCH_ASSOC);
  $out=[];
  foreach($rows as $c){
    if(!empty($c['paid_content']) || !empty($c['paid_content_locked'])) continue;
    try{$s=resolve_active_source($c);}catch(Throwable $e){$s=null;}
    if(!$s || empty($s['url'])) continue;
    $t=strtolower((string)($s['type']??''));
    if(!in_array($t,['mp4','m3u8','hls'],true)) continue;
    $u=trim((string)$s['url']); if(!preg_match('~^https://~i',$u)) continue;
    $out[]=['id'=>(int)$c['id'],'title'=>(string)$c['title'],'slug'=>(string)$c['slug'],'description'=>(string)($c['description']??''),'type'=>(string)($c['type']??'tv'),'logo'=>(string)($c['logo_url']??''),'stream'=>$u,'format'=>$t==='mp4'?'mp4':'hls'];
  }
  return $out;
}
function sl_external_json_headers(): void {header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');}
