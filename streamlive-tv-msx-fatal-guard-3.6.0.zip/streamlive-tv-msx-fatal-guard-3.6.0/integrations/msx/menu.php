<?php
// StreamLive MSX fatal guard: always return valid JSON to MSX and log server-side details.
ini_set('display_errors', '0');
error_reporting(E_ALL);
if (!ob_get_level()) { ob_start(); }
function sl_msx_fallback($title, $description) {
    if (ob_get_level()) { ob_clean(); }
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, private');
        header('Access-Control-Allow-Origin: *');
        http_response_code(200);
    }
    echo json_encode(['headline'=>'StreamLive','items'=>[['title'=>$title,'description'=>$description,'type'=>'text']]], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR], true)) {
        error_log('[StreamLive MSX fatal] '.$e['message'].' in '.$e['file'].':'.$e['line']);
        sl_msx_fallback('Ошибка сервера StreamLive', 'Серверная ошибка записана в журнал. Проверьте error_log хостинга.');
    }
});
try {
    require_once dirname(__DIR__).'/shared/api.php';
    $base = 'https://'.($_SERVER['HTTP_HOST'] ?? 'streamlivetv.freedev.app');
    $client = trim((string)($_GET['client_id'] ?? ''));
    if ($client === '' || strlen($client) > 100 || !preg_match('/^[A-Za-z0-9._:-]+$/', $client)) {
        sl_ext_json(['headline'=>'StreamLive','menu'=>[
            ['label'=>'Ошибка ID устройства','icon'=>'user','data'=>$base.'/integrations/msx/connect.php']
        ]]);
    }
    $connected = (bool)sl_ext_msx_user();
    if (!$connected) {
        sl_ext_json(['headline'=>'StreamLive','menu'=>[
            ['label'=>'Подключить аккаунт','icon'=>'user','data'=>$base.'/integrations/msx/connect.php?client_id='.rawurlencode($client)],
            ['label'=>'Обновить','icon'=>'reload','data'=>$base.'/integrations/msx/menu.php?client_id='.rawurlencode($client)]
        ]]);
    }
    sl_ext_json(['headline'=>'StreamLive','menu'=>[
        ['label'=>'Все каналы','icon'=>'live','data'=>$base.'/integrations/msx/content.php?client_id='.rawurlencode($client)],
        ['label'=>'Избранное','icon'=>'favorite','data'=>$base.'/integrations/msx/content.php?view=favorites&client_id='.rawurlencode($client)],
        ['label'=>'Профиль','icon'=>'user','data'=>$base.'/integrations/msx/profile.php?client_id='.rawurlencode($client)]
    ]]);

} catch (Throwable $e) {
    error_log('[StreamLive MSX exception] '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());
    sl_msx_fallback('Ошибка сервера StreamLive', 'Не удалось обработать запрос. Подробности записаны в error_log хостинга.');
}
