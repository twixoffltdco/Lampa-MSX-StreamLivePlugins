StreamLive External App Adapters 3.2.0

Lampa: native Lampa plugin, registers a StreamLive sidebar item and its own Activity components.
Media Station X: native MSX Start/Menu/Content JSON adapter.
Shared: device authorization and account/favorites API.

The integration reuses StreamLivePHP v28.53 authentication and the existing channel favorites table. It does not replace the StreamLive engine or Native App.
