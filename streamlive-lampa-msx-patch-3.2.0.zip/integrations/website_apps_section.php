<?php
// TV-app setup chooser. This page never attempts a silent install: each TV shell
// must approve its own plugin/start-parameter configuration.
$__slScheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') ? 'https' : 'http';
$__slHost = preg_replace('/[^A-Za-z0-9.:-]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
$__slRoot = $__slScheme . '://' . ($__slHost ?: 'localhost');
$__slLampa = $__slRoot . '/integrations/lampa/plugin.js';
$__slMsx = $__slRoot . '/integrations/msx/start.json';
?>
<section id="streamlive-tv-apps" class="sl-tv-apps" aria-labelledby="sl-tv-apps-title">
  <div class="sl-tv-apps-inner">
    <div class="sl-tv-apps-kicker">STREAMLIVE · ПОДКЛЮЧЕНИЕ К TV</div>
    <h2 id="sl-tv-apps-title">Запусти StreamLive внутри своего приложения</h2>
    <p class="sl-tv-apps-lead">Выбери установленную оболочку. Здесь откроется инструкция именно для неё — StreamLive будет отдельным разделом, а не обычной страницей сайта.</p>
    <div class="sl-tv-choice-grid">
      <button type="button" class="sl-tv-choice" data-sl-open="lampa"><span class="sl-tv-choice-logo">▶</span><strong>Lampa</strong><small>Подключить расширение</small></button>
      <button type="button" class="sl-tv-choice" data-sl-open="msx"><span class="sl-tv-choice-logo">▣</span><strong>Media Station X</strong><small>Подключить Start Parameter</small></button>
    </div>
    <div class="sl-tv-details" id="sl-tv-lampa" hidden>
      <h3>Lampa — подключение расширения</h3>
      <ol>
        <li>Открой именно приложение Lampa, не браузер с сайтом StreamLive.</li>
        <li>В боковом меню открой <b>Настройки → Расширения</b>. В некоторых сборках Lampa этот пункт может быть отключён или отсутствовать.</li>
        <li>Если есть пункт <b>Добавить плагин</b>, вставь адрес ниже и подтверди установку.</li>
        <li>Полностью перезапусти Lampa. В боковом меню должен появиться отдельный пункт <b>StreamLive</b>.</li>
        <li>Открой StreamLive и подтверди код на сайте. Пароль на телевизоре не вводится.</li>
      </ol>
      <code><?= htmlspecialchars($__slLampa, ENT_QUOTES, 'UTF-8') ?></code>
      <button type="button" class="sl-tv-copy" data-copy="<?= htmlspecialchars($__slLampa, ENT_QUOTES, 'UTF-8') ?>">Скопировать адрес расширения</button>
      <p class="sl-tv-warning">Если в твоей версии Lampa вообще нет «Расширения / Добавить плагин», сайт не может принудительно установить туда скрипт. Нужна версия Lampa с поддержкой сторонних плагинов либо совместимый способ установки от разработчика твоей сборки.</p>
    </div>
    <div class="sl-tv-details" id="sl-tv-msx" hidden>
      <h3>Media Station X — подключение Start Parameter</h3>
      <ol>
        <li>Открой приложение <b>Media Station X</b> на телевизоре.</li>
        <li>Перейди в <b>Settings → Start Parameter → Setup</b>.</li>
        <li>Введи адрес JSON ниже. Для HTTPS включи значок замка / Security Lock.</li>
        <li>Подтверди настройку. После загрузки меню StreamLive будет открываться при запуске MSX.</li>
        <li>Выбери StreamLive → Connect account и подтверди код на сайте.</li>
      </ol>
      <code><?= htmlspecialchars($__slMsx, ENT_QUOTES, 'UTF-8') ?></code>
      <button type="button" class="sl-tv-copy" data-copy="<?= htmlspecialchars($__slMsx, ENT_QUOTES, 'UTF-8') ?>">Скопировать Start Parameter</button>
      <p class="sl-tv-warning">MSX использует собственное меню и JSON API. Здесь не открывается веб-страница StreamLive.</p>
    </div>
    <p class="sl-tv-footnote">Важно: ни Lampa, ни Media Station X не разрешают сайту тайно установить расширение при обычном посещении сайта. Подключение подтверждается в самой оболочке. После установки интерфейс StreamLive открывается уже внутри неё.</p>
  </div>
</section>
<style>
.sl-tv-apps{padding:clamp(28px,5vw,64px) 20px;margin:48px auto;max-width:1180px;color:var(--foreground,#f7f8fc)}
.sl-tv-apps-inner{padding:clamp(24px,4vw,48px);border:1px solid #397a70;border-radius:26px;background:radial-gradient(100% 130% at 0 0,rgba(32,185,149,.24),transparent 58%),linear-gradient(145deg,#17243b,#081321);box-shadow:0 24px 80px #0007;text-align:center}
.sl-tv-apps-kicker{font-size:12px;font-weight:900;letter-spacing:.16em;color:#8cebd4}.sl-tv-apps h2{font-size:clamp(27px,4vw,42px);line-height:1.12;margin:16px auto;max-width:850px}.sl-tv-apps-lead{color:#d0d9e7;max-width:760px;margin:0 auto 28px;line-height:1.65}
.sl-tv-choice-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;max-width:850px;margin:0 auto}.sl-tv-choice{min-height:150px;border:1px solid #527087;border-radius:18px;background:linear-gradient(145deg,#203753,#111f31);color:white;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;transition:.18s}.sl-tv-choice:hover,.sl-tv-choice:focus{border-color:#42d7b2;transform:translateY(-2px);outline:2px solid #42d7b255}.sl-tv-choice-logo{font-size:34px;color:#72e4c6}.sl-tv-choice strong{font-size:24px}.sl-tv-choice small{font-size:13px;color:#c3d1df}
.sl-tv-details{max-width:850px;margin:24px auto 0;padding:24px;text-align:left;border:1px solid #405a70;border-radius:18px;background:#0c1929}.sl-tv-details h3{font-size:23px;margin:0 0 14px;color:white}.sl-tv-details ol{padding-left:24px;color:#d5deea;line-height:1.7}.sl-tv-details code{display:block;overflow-wrap:anywhere;color:#9ee9d5;font-size:13px;background:#06101d;padding:14px;border-radius:9px;margin:16px 0}.sl-tv-copy{border:0;border-radius:10px;padding:13px 18px;background:#20b995;color:#06231d;font-weight:900;cursor:pointer}.sl-tv-warning{color:#ffd28b;line-height:1.55;font-size:13px;margin-top:16px}.sl-tv-footnote{font-size:12px;color:#aebbd0;line-height:1.6;margin:22px auto 0;max-width:850px}
@media(max-width:650px){.sl-tv-choice-grid{grid-template-columns:1fr}.sl-tv-choice{min-height:120px}.sl-tv-details{padding:18px}}
</style>
<script>
(function(){
  document.querySelectorAll('[data-sl-open]').forEach(function(button){button.addEventListener('click',function(){var target=document.getElementById('sl-tv-'+button.getAttribute('data-sl-open'));document.querySelectorAll('.sl-tv-details').forEach(function(panel){panel.hidden=panel!==target;});if(target){target.hidden=false;target.scrollIntoView({behavior:'smooth',block:'nearest'});}});});
  document.querySelectorAll('.sl-tv-copy').forEach(function(button){button.addEventListener('click',function(){var value=button.getAttribute('data-copy')||'';var old=button.textContent;function done(){button.textContent='Скопировано';setTimeout(function(){button.textContent=old;},1800);}function fallback(){var area=document.createElement('textarea');area.value=value;area.style.position='fixed';area.style.opacity='0';document.body.appendChild(area);area.select();try{document.execCommand('copy');done();}catch(e){button.textContent='Скопируйте адрес вручную';}area.remove();}if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(value).then(done).catch(fallback);}else fallback();});});
})();
</script>
