<?php
// Shared centered TV-app chooser. Included on landing and regular site pages only.
if (defined('SL_TV_APPS_MODAL_RENDERED')) return;
define('SL_TV_APPS_MODAL_RENDERED', true);
$__slScheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') ? 'https' : 'http';
$__slHost = preg_replace('/[^A-Za-z0-9.:-]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
$__slRoot = $__slScheme . '://' . ($__slHost ?: 'localhost');
$__slLampa = $__slRoot . '/integrations/lampa/plugin.js';
$__slMsx = $__slRoot . '/integrations/msx/start.json';
$__slReqPath = (string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/');
$__slAutoShow = ($__slReqPath === '/' || basename($__slReqPath) === 'index_landing.php') ? '1' : '0';
?>
<div id="sl-tv-modal" class="sl-tv-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="sl-tv-modal-title">
  <div class="sl-tv-modal-backdrop" data-sl-close></div>
  <section class="sl-tv-modal-card">
    <button type="button" class="sl-tv-modal-close" data-sl-close aria-label="Закрыть">×</button>
    <div class="sl-tv-modal-kicker">STREAMLIVE · TV APPS</div>
    <div class="sl-tv-modal-mark">▶</div>
    <h2 id="sl-tv-modal-title">Смотри StreamLive в любимой оболочке</h2>
    <p class="sl-tv-modal-lead">Выбери приложение. StreamLive будет открываться отдельным разделом внутри его интерфейса, а не как обычная веб-страница.</p>
    <div class="sl-tv-modal-choices">
      <button type="button" class="sl-tv-app-choice" data-sl-show="lampa"><span class="sl-tv-app-icon">▶</span><b>Lampa</b><small>Подключить расширение</small></button>
      <button type="button" class="sl-tv-app-choice" data-sl-show="msx"><span class="sl-tv-app-icon">▦</span><b>Media Station X</b><small>Настроить Start Parameter</small></button>
    </div>
    <div class="sl-tv-modal-panel" id="sl-tv-panel-lampa" hidden>
      <h3>Подключение Lampa</h3>
      <p>В твоей сборке Lampa может отсутствовать встроенный каталог расширений. Если доступна функция добавления плагина, используй адрес ниже. Если её нет, потребуется сборка Lampa с поддержкой сторонних плагинов — сайт не может установить расширение скрытно.</p>
      <div class="sl-tv-address"><?= htmlspecialchars($__slLampa, ENT_QUOTES, 'UTF-8') ?></div>
      <button type="button" class="sl-tv-copy" data-sl-copy="<?= htmlspecialchars($__slLampa, ENT_QUOTES, 'UTF-8') ?>">Скопировать адрес плагина</button>
      <p class="sl-tv-note">После успешной загрузки плагина открой пункт StreamLive в меню Lampa и подтверди вход кодом.</p>
    </div>
    <div class="sl-tv-modal-panel" id="sl-tv-panel-msx" hidden>
      <h3>Подключение Media Station X</h3>
      <p>На телевизоре открой Settings → Start Parameter → Setup и укажи адрес ниже. Для HTTPS включи Security Lock, если приложение этого требует.</p>
      <div class="sl-tv-address"><?= htmlspecialchars($__slMsx, ENT_QUOTES, 'UTF-8') ?></div>
      <button type="button" class="sl-tv-copy" data-sl-copy="<?= htmlspecialchars($__slMsx, ENT_QUOTES, 'UTF-8') ?>">Скопировать Start Parameter</button>
      <p class="sl-tv-note">После настройки откроется собственное меню Media Station X. Затем выбери Connect account и подтверди код на сайте.</p>
    </div>
    <div class="sl-tv-modal-footer">Можно закрыть это окно и вернуться к подключению позже — ссылка останется в футере сайта.</div>
  </section>
</div>
<style>
.sl-tv-modal{position:fixed;inset:0;z-index:100050;display:none;align-items:center;justify-content:center;padding:22px;box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,sans-serif}.sl-tv-modal.is-open{display:flex}.sl-tv-modal-backdrop{position:absolute;inset:0;background:rgba(2,7,16,.82);backdrop-filter:blur(8px)}.sl-tv-modal-card{position:relative;z-index:1;width:min(900px,100%);max-height:min(90vh,900px);overflow:auto;box-sizing:border-box;padding:clamp(24px,4vw,46px);border:1px solid rgba(94,226,196,.48);border-radius:26px;background:radial-gradient(ellipse at 50% 0,rgba(28,190,153,.25),transparent 48%),linear-gradient(145deg,#17263c,#071321 76%);box-shadow:0 28px 100px #000b;color:#f7fbff;text-align:center}.sl-tv-modal-close{position:absolute;right:18px;top:12px;width:42px;height:42px;border:1px solid #60758a;border-radius:50%;background:#ffffff12;color:white;font-size:30px;cursor:pointer}.sl-tv-modal-kicker{font-size:12px;font-weight:900;letter-spacing:.2em;color:#82e8d0}.sl-tv-modal-mark{display:grid;place-items:center;margin:18px auto 8px;width:58px;height:58px;border-radius:18px;background:#20b995;color:#05251f;font-size:27px}.sl-tv-modal-card h2{max-width:720px;margin:12px auto;font-size:clamp(28px,4.4vw,43px);line-height:1.12}.sl-tv-modal-lead{max-width:680px;margin:0 auto 26px;color:#cbd8e8;line-height:1.6}.sl-tv-modal-choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;max-width:720px;margin:0 auto}.sl-tv-app-choice{min-height:142px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;border:1px solid #557087;border-radius:18px;background:linear-gradient(145deg,#203953,#101e30);color:#fff;cursor:pointer}.sl-tv-app-choice:hover,.sl-tv-app-choice:focus{outline:3px solid #20b995;border-color:#20b995}.sl-tv-app-icon{font-size:30px;color:#7be5ca}.sl-tv-app-choice b{font-size:23px}.sl-tv-app-choice small{font-size:13px;color:#c3d0df}.sl-tv-modal-panel{max-width:720px;margin:20px auto 0;padding:22px;text-align:left;border:1px solid #425c73;border-radius:16px;background:#081625}.sl-tv-modal-panel h3{margin:0 0 10px;font-size:22px}.sl-tv-modal-panel p{color:#d1dbea;line-height:1.6}.sl-tv-address{padding:13px;margin:14px 0;overflow-wrap:anywhere;border-radius:9px;background:#020b15;color:#9cebd7;font-size:13px}.sl-tv-copy{padding:12px 18px;border:0;border-radius:9px;background:#20b995;color:#06251e;font-weight:800;cursor:pointer}.sl-tv-note{font-size:13px!important;color:#aebed0!important}.sl-tv-modal-footer{margin-top:20px;color:#aab8c9;font-size:12px;line-height:1.5}.sl-tv-footer-trigger{display:inline-flex!important;margin:9px 12px!important;padding:9px 14px;border:1px solid #20b995;border-radius:999px;color:#20b995!important;font-weight:800;text-decoration:none!important}.sl-tv-footer-trigger:hover{background:#20b99518}@media(max-width:620px){.sl-tv-modal{padding:10px}.sl-tv-modal-card{padding:25px 16px 20px;border-radius:18px}.sl-tv-modal-choices{grid-template-columns:1fr}.sl-tv-app-choice{min-height:105px}.sl-tv-modal-panel{padding:16px}}
</style>
<script>
(function(){
 var modal=document.getElementById('sl-tv-modal');if(!modal||modal.dataset.bound==='1')return;modal.dataset.bound='1';
 function open(){modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
 function close(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.style.overflow='';try{localStorage.setItem('sl_tv_modal_seen',String(Date.now()));}catch(e){}}
 document.querySelectorAll('[data-sl-close]').forEach(function(x){x.addEventListener('click',close);});
 document.querySelectorAll('[data-sl-show]').forEach(function(b){b.addEventListener('click',function(){var key=b.getAttribute('data-sl-show');document.querySelectorAll('.sl-tv-modal-panel').forEach(function(p){p.hidden=p.id!=='sl-tv-panel-'+key;});});});
 document.querySelectorAll('[data-sl-copy]').forEach(function(b){b.addEventListener('click',function(){var value=b.getAttribute('data-sl-copy')||'';var old=b.textContent;function ok(){b.textContent='Скопировано ✓';setTimeout(function(){b.textContent=old;},1800);}function fallback(){var t=document.createElement('textarea');t.value=value;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();try{document.execCommand('copy');ok();}catch(e){b.textContent='Скопируйте адрес вручную';}t.remove();}if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(value).then(ok).catch(fallback);else fallback();});});
 document.querySelectorAll('.sl-tv-footer-trigger').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();open();});});
 document.addEventListener('keydown',function(e){if(e.key==='Escape'&&modal.classList.contains('is-open'))close();});
 var auto=<?= $__slAutoShow ?>;var seen=0;try{seen=Number(localStorage.getItem('sl_tv_modal_seen')||0);}catch(e){};if(auto&&(!seen||Date.now()-seen>30*24*60*60*1000)){setTimeout(open,650);}
})();
</script>
