<?php
// Compatibility include retained for older deployments.
$__slPathCandidates = [(string)($_SERVER['REQUEST_URI'] ?? ''), (string)($_SERVER['PHP_SELF'] ?? ''), (string)($_SERVER['SCRIPT_NAME'] ?? '')];
$__slExcluded = false;
foreach ($__slPathCandidates as $__slCandidate) { $__slPath = (string)(parse_url($__slCandidate, PHP_URL_PATH) ?? $__slCandidate); if (preg_match('~(?:^|/)(?:platforma|native|native-app)(?:/|$)~i', $__slPath)) { $__slExcluded = true; break; } }
$__slExcluded = $__slExcluded || (($_COOKIE['sl_native_app'] ?? '') === '1') || !empty($_COOKIE['streamlive_native_app']);
if (!$__slExcluded && is_file(__DIR__ . '/tv_apps_modal.php')) require __DIR__ . '/tv_apps_modal.php';
