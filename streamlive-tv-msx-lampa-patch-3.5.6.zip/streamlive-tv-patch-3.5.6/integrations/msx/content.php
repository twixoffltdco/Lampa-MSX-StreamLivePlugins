<?php
require_once dirname(__DIR__).'/shared/api.php';
$base='https://'.($_SERVER['HTTP_HOST']??'');$user=sl_ext_msx_user();$client=trim((string)($_GET['client_id']??''));
if(!$user)sl_ext_json(['headline'=>'StreamLive','items'=>[['title'=>'Сначала подключите аккаунт','description'=>'Откройте раздел «Подключить аккаунт» в меню StreamLive.','type'=>'text']]]);
if(($_GET['view']??'')==='favorites'){
  $st=db()->prepare("SELECT c.id,c.slug,c.title,c.description,c.type,c.logo_url,c.owner_id,c.views,c.paid_content,c.paid_content_locked,c.is_broadcast_paused FROM favorites f JOIN channels c ON c.id=f.channel_id WHERE f.user_id=? AND c.status='approved' AND COALESCE(c.paid_content,0)=0 AND COALESCE(c.paid_content_locked,0)=0 ORDER BY f.created_at DESC");
  $st->execute([(int)$user['id']]);$rows=$st->fetchAll(PDO::FETCH_ASSOC)?:[];
  foreach($rows as &$favorite){
    try{$source=resolve_active_source($favorite);}catch(Throwable $e){$source=null;}
    $favorite['stream']=is_array($source)?(string)($source['url']??''):'';
    $kind=strtolower((string)($source['type']??''));$favorite['format']=$kind==='mp4'?'mp4':'hls';
  }unset($favorite);
}else{$rows=sl_ext_catalog();}
$items=[];foreach($rows as $c){
  $stream=trim((string)($c['stream']??''));if($stream===''||!filter_var($stream,FILTER_VALIDATE_URL)||stripos($stream,'https://')!==0)continue;
  $items[]=['title'=>$c['title'],'image'=>$c['logo']??$c['logo_url']??'','description'=>$c['description']??'','action'=>'video:'.$stream,'type'=>'video'];
  $items[]=['title'=>'☆ Избранное · '.$c['title'],'description'=>'Добавить или убрать канал из избранного','action'=>'execute:'.$base.'/integrations/msx/favorite_action?client_id='.rawurlencode($client),'data'=>['channel_id'=>(int)$c['id']],'type'=>'link'];
}
sl_ext_json(['type'=>'content','headline'=>($_GET['view']??'')==='favorites'?'StreamLive · Избранное':'StreamLive · Каналы','template'=>['type'=>'default','layout'=>'0,0,3,2','imageFiller'=>'cover','action'=>'video'], 'items'=>$items,'provider'=>['name'=>'StreamLive','icon'=>$base.'/favicon.ico']]);
