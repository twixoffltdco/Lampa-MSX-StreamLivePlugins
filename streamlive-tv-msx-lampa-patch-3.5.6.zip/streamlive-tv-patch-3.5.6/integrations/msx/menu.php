<?php
require_once dirname(__DIR__).'/shared/api.php';
$base='https://'.($_SERVER['HTTP_HOST']??'');$client=trim((string)($_GET['client_id']??''));
if(!sl_ext_msx_user())sl_ext_json(['headline'=>'StreamLive','menu'=>[['label'=>'Подключить аккаунт','icon'=>'user','data'=>['type'=>'content','url'=>$base.'/integrations/msx/connect?client_id='.rawurlencode($client)]],['label'=>'Обновить','icon'=>'reload','data'=>['type'=>'content','url'=>$base.'/integrations/msx/menu?client_id='.rawurlencode($client)]]]]);
sl_ext_json(['headline'=>'StreamLive','menu'=>[
 ['label'=>'Все каналы','icon'=>'live','data'=>['type'=>'content','url'=>$base.'/integrations/msx/content?client_id='.rawurlencode($client)]],
 ['label'=>'Избранное','icon'=>'favorite','data'=>['type'=>'content','url'=>$base.'/integrations/msx/content?view=favorites&client_id='.rawurlencode($client)]],
 ['label'=>'Профиль','icon'=>'user','data'=>['type'=>'content','url'=>$base.'/integrations/msx/profile?client_id='.rawurlencode($client)]]
]]);
