<?php
// StreamLive MSX fatal guard: always return valid JSON to MSX and log server-side details.
ini_set('display_errors', '0');
error_reporting(E_ALL);
if (!ob_get_level()) { ob_start(); }
function sl_msx_fallback($title, $description) {
    if (ob_get_level()) { ob_clean(); }
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, private');
        header('Access-Control-Allow-Origin: *');
        http_response_code(200);
    }
    echo json_encode(['headline'=>'StreamLive','items'=>[['title'=>$title,'description'=>$description,'type'=>'text']]], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR], true)) {
        error_log('[StreamLive MSX fatal] '.$e['message'].' in '.$e['file'].':'.$e['line']);
        sl_msx_fallback('Ошибка сервера StreamLive', 'Серверная ошибка записана в журнал. Проверьте error_log хостинга.');
    }
});
try {
    require_once dirname(__DIR__).'/shared/api.php';
    $base = 'https://'.($_SERVER['HTTP_HOST'] ?? 'streamlivetv.freedev.app');
    $user = sl_ext_msx_user();
    $client = trim((string)($_GET['client_id'] ?? ''));
    if (!$user) {
        sl_ext_json(['type'=>'pages','headline'=>'StreamLive','template'=>['type'=>'separate','layout'=>'0,0,12,1','title'=>'StreamLive'],'items'=>[
            ['title'=>'Сначала подключите аккаунт','description'=>'Откройте раздел «Подключить аккаунт» в меню StreamLive.','action'=>'link:'.$base.'/integrations/msx/connect?client_id='.rawurlencode($client)]
        ]]);
    }
    if (($_GET['view'] ?? '') === 'favorites') {
        $st = db()->prepare("SELECT c.id,c.slug,c.title,c.description,c.type,c.logo_url,c.owner_id,c.views,c.paid_content,c.paid_content_locked,c.is_broadcast_paused FROM favorites f JOIN channels c ON c.id=f.channel_id WHERE f.user_id=? AND c.status='approved' AND COALESCE(c.paid_content,0)=0 AND COALESCE(c.paid_content_locked,0)=0 ORDER BY f.created_at DESC");
        $st->execute([(int)$user['id']]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as &$favorite) {
            try { $source = resolve_active_source($favorite); } catch (Throwable $e) { $source = null; }
            $favorite['stream'] = is_array($source) ? (string)($source['url'] ?? '') : '';
            $favorite['format'] = strtolower((string)($source['type'] ?? '')) === 'mp4' ? 'mp4' : 'hls';
        }
        unset($favorite);
    } else {
        $rows = sl_ext_catalog();
    }
    $items = [];
    foreach ($rows as $channel) {
        $stream = trim((string)($channel['stream'] ?? ''));
        if ($stream === '' || !filter_var($stream, FILTER_VALIDATE_URL) || stripos($stream, 'https://') !== 0) continue;
        $items[] = [
            'title'=>(string)($channel['title'] ?? 'Канал'),
            'image'=>(string)($channel['logo'] ?? $channel['logo_url'] ?? ''),
            'description'=>(string)($channel['description'] ?? ''),
            'action'=>'video:'.$stream
        ];
    }
    sl_ext_json([
        'type'=>'pages',
        'headline'=>(($_GET['view'] ?? '') === 'favorites' ? 'StreamLive · Избранное' : 'StreamLive · Каналы'),
        'template'=>['type'=>'separate','layout'=>'0,0,3,2','imageFiller'=>'cover','action'=>'video'],
        'items'=>$items,
        'provider'=>['name'=>'StreamLive','icon'=>$base.'/favicon.ico']
    ]);

} catch (Throwable $e) {
    error_log('[StreamLive MSX exception] '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine());
    sl_msx_fallback('Ошибка сервера StreamLive', 'Не удалось обработать запрос. Подробности записаны в error_log хостинга.');
}
