<?php
require_once dirname(__DIR__).'/shared/api.php';$u=sl_ext_msx_user();if(!$u)sl_ext_json(['headline'=>'StreamLive','items'=>[['title'=>'Аккаунт не подключён','type'=>'text']]]);
sl_ext_json(['headline'=>'StreamLive · Профиль','items'=>[['title'=>'Вы вошли в StreamLive','description'=>(string)($u['username']??$u['name']??'Пользователь'),'type'=>'text'],['title'=>'Управление подключениями','description'=>'Откройте настройки аккаунта на сайте StreamLive, чтобы отозвать доступ устройства.','action'=>'link:https://'.($_SERVER['HTTP_HOST']??'').'/integrations/devices.php','type'=>'link']]]);
