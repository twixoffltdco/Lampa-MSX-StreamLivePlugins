<?php
require_once dirname(__DIR__).'/shared/api.php';
$client=trim((string)($_GET['client_id']??''));if($client===''||strlen($client)>100||!preg_match('/^[A-Za-z0-9._:-]+$/',$client))sl_ext_json(['headline'=>'StreamLive','items'=>[['title'=>'Не удалось определить устройство','description'=>'Перезапустите Media Station X.','type'=>'text']]]);
if(sl_ext_msx_user()){sl_ext_json(['headline'=>'StreamLive · Аккаунт подключён','items'=>[['title'=>'Аккаунт StreamLive подключён','description'=>'Вернитесь в главное меню.','type'=>'text']]]);}
$code=strtoupper(substr(bin2hex(random_bytes(4)),0,4).'-'.substr(bin2hex(random_bytes(4)),0,4));
$st=db()->prepare("INSERT INTO external_app_devices(app,device_code_hash,user_code_hash,device_name,client_id,expires_at) VALUES('msx',?,?,?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE))");$st->execute([hash('sha256',bin2hex(random_bytes(32))),hash('sha256',$code),'Media Station X',$client]);
$base='https://'.($_SERVER['HTTP_HOST']??'');$url=$base.'/integrations/authorize?code='.rawurlencode($code);
sl_ext_json(['headline'=>'Подключение StreamLive','template'=>['type'=>'default','layout'=>'0,0,6,3','color'=>'msx-glass'],'items'=>[
 ['title'=>'Подключите аккаунт StreamLive','description'=>'На телефоне или компьютере откройте страницу подтверждения и введите код ниже. Код действует 10 минут.','type'=>'text'],
 ['title'=>$code,'description'=>'Код подключения','type'=>'text'],
 ['title'=>'Открыть страницу подтверждения','description'=>$url,'action'=>'link:'.$url,'type'=>'link'],
 ['title'=>'Проверить подключение','description'=>'Вернитесь в меню StreamLive после подтверждения.','action'=>'menu:'. $base.'/integrations/msx/menu?client_id='.rawurlencode($client),'type'=>'link']
]]);
