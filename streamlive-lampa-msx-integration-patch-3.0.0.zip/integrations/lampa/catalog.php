<?php
require_once dirname(__DIR__).'/shared/api.php';
$items=sl_ext_catalog();
sl_ext_json(['title'=>'StreamLive','version'=>'1.0.0','items'=>$items]);
