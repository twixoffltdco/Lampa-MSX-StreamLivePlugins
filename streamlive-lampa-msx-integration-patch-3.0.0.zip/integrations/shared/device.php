<?php
require_once __DIR__.'/api.php';
$in=sl_ext_input(); $action=(string)($_GET['action']??$in['action']??'');
if($action==='request'){
  $app=sl_ext_app((string)($in['app']??'')); if($app==='unknown')sl_ext_json(['ok'=>false,'error'=>'bad_app'],400);
  $clientId=trim((string)($in['client_id']??'')); if($app==='msx' && ($clientId===''||strlen($clientId)>100||!preg_match('/^[A-Za-z0-9._:-]+$/',$clientId)))sl_ext_json(['ok'=>false,'error'=>'bad_client_id'],400);
  $device=bin2hex(random_bytes(32)); $userCode=strtoupper(substr(bin2hex(random_bytes(4)),0,4).'-'.substr(bin2hex(random_bytes(4)),0,4));
  $st=db()->prepare("INSERT INTO external_app_devices(app,device_code_hash,user_code_hash,device_name,client_id,expires_at) VALUES(?,?,?,?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE))");
  $st->execute([$app,hash('sha256',$device),hash('sha256',$userCode),substr((string)($in['device_name']??'TV'),0,120),$clientId?:null]);
  $base=rtrim(((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'https').'://'.($_SERVER['HTTP_HOST']??''),'/');
  sl_ext_json(['ok'=>true,'device_code'=>$device,'user_code'=>$userCode,'verification_uri'=>$base.'/integrations/authorize.php','verification_uri_complete'=>$base.'/integrations/authorize.php?code='.rawurlencode($userCode),'expires_in'=>600,'interval'=>5]);
}
if($action==='poll'){
  $device=(string)($in['device_code']??''); if(!preg_match('/^[a-f0-9]{64}$/',$device))sl_ext_json(['ok'=>false,'error'=>'invalid_request'],400);
  $pdo=db(); $pdo->beginTransaction();
  try{
    $st=$pdo->prepare('SELECT * FROM external_app_devices WHERE device_code_hash=? LIMIT 1 FOR UPDATE');$st->execute([hash('sha256',$device)]);$d=$st->fetch();
    if(!$d){$pdo->commit();sl_ext_json(['ok'=>false,'error'=>'invalid_grant'],400);}
    if(strtotime($d['expires_at'])<time()){$pdo->prepare("UPDATE external_app_devices SET status='expired' WHERE id=?")->execute([$d['id']]);$pdo->commit();sl_ext_json(['ok'=>false,'error'=>'expired_token'],400);}
    if($d['status']==='pending'){$pdo->commit();sl_ext_json(['ok'=>true,'status'=>'authorization_pending']);}
    if($d['status']!=='approved'){$pdo->commit();sl_ext_json(['ok'=>false,'error'=>'access_denied'],403);}
    if(!empty($d['token_issued'])){$pdo->commit();sl_ext_json(['ok'=>false,'error'=>'token_already_issued'],400);}
    $token=bin2hex(random_bytes(32));
    $pdo->prepare('INSERT INTO external_app_tokens(user_id,app,token_hash,device_name) VALUES(?,?,?,?)')->execute([(int)$d['user_id'],$d['app'],hash('sha256',$token),$d['device_name']]);
    $pdo->prepare('UPDATE external_app_devices SET token_issued=1 WHERE id=?')->execute([$d['id']]); $pdo->commit();
    sl_ext_json(['ok'=>true,'status'=>'authorized','access_token'=>$token,'token_type'=>'Bearer','expires_in'=>null]);
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log('[external device poll] '.$e->getMessage());sl_ext_json(['ok'=>false,'error'=>'server_error'],500);}
}
if($action==='revoke'){
  $u=sl_ext_require_token(); $pdo=db(); $pdo->prepare('UPDATE external_app_tokens SET revoked_at=NOW() WHERE token_hash=? AND user_id=?')->execute([hash('sha256',(string)($in['access_token']??'')),(int)$u['id']]);sl_ext_json(['ok'=>true]);
}
sl_ext_json(['ok'=>false,'error'=>'not_found'],404);
