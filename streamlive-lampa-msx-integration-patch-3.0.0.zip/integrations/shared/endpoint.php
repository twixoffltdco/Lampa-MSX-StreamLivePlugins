<?php
require_once __DIR__.'/api.php';
$u=sl_ext_require_token();$action=(string)($_GET['action']??'catalog');
if($action==='me'){sl_ext_json(['ok'=>true,'user'=>['id'=>(int)$u['id'],'name'=>(string)($u['username']??$u['name']??'StreamLive')]]);}
if($action==='catalog'){
  $items=sl_ext_catalog();$st=db()->prepare('SELECT channel_id FROM favorites WHERE user_id=?');$st->execute([(int)$u['id']]);$fav=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN));
  foreach($items as &$item)$item['favorite']=in_array((int)$item['id'],$fav,true);unset($item);
  sl_ext_json(['ok'=>true,'title'=>'StreamLive','items'=>$items]);
}
if($action==='favorites'){
  $st=db()->prepare('SELECT c.id,c.slug,c.title,c.description,c.type,c.logo_url FROM favorites f JOIN channels c ON c.id=f.channel_id WHERE f.user_id=? AND c.status=\'approved\' AND COALESCE(c.paid_content,0)=0 AND COALESCE(c.paid_content_locked,0)=0 ORDER BY f.created_at DESC');$st->execute([(int)$u['id']]);sl_ext_json(['ok'=>true,'items'=>$st->fetchAll()?:[]]);
}
if($action==='favorite' && $_SERVER['REQUEST_METHOD']==='POST'){
  $in=sl_ext_input();$id=(int)($in['channel_id']??0);if($id<1)sl_ext_json(['ok'=>false,'error'=>'bad_channel'],400);
  $st=db()->prepare("SELECT id FROM channels WHERE id=? AND status='approved' AND COALESCE(paid_content,0)=0 AND COALESCE(paid_content_locked,0)=0 AND COALESCE(is_broadcast_paused,0)=0");$st->execute([$id]);if(!$st->fetch())sl_ext_json(['ok'=>false,'error'=>'not_available'],404);
  $st=db()->prepare('SELECT id FROM favorites WHERE user_id=? AND channel_id=?');$st->execute([(int)$u['id'],$id]);
  if($st->fetch()) {db()->prepare('DELETE FROM favorites WHERE user_id=? AND channel_id=?')->execute([(int)$u['id'],$id]);$fav=false;}
  else {db()->prepare('INSERT IGNORE INTO favorites(user_id,channel_id) VALUES(?,?)')->execute([(int)$u['id'],$id]);$fav=true;}
  sl_ext_json(['ok'=>true,'favorite'=>$fav]);
}
sl_ext_json(['ok'=>false,'error'=>'not_found'],404);
