StreamLive External App Adapters 3.0.0

lampa/        Lampa plugin
msx/          Media Station X Start/Menu/Content adapter
shared/       Device authorization and account/favorites API
authorize.php StreamLive website approval screen
 devices.php  Active external-app sessions and revocation

This integration reuses StreamLivePHP v28.53 authentication and the existing channel favorites table. It does not replace the StreamLive engine or Native App.
