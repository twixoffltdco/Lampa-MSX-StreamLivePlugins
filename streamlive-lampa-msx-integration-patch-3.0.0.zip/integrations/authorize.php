<?php
require_once dirname(__DIR__).'/includes/functions.php';
require_once dirname(__DIR__).'/includes/auth.php';
require_once __DIR__.'/shared/api.php';
$code=strtoupper(trim((string)($_GET['code']??$_POST['code']??'')));
$ok=false;$message='Введите код, показанный в приложении.';
if($code!=='' && preg_match('/^[A-F0-9]{4}-[A-F0-9]{4}$/',$code)){
  $st=db()->prepare("SELECT * FROM external_app_devices WHERE user_code_hash=? AND status='pending' AND expires_at>NOW() LIMIT 1");$st->execute([hash('sha256',$code)]);$device=$st->fetch();
  if(!$device)$message='Код не найден или срок его действия истёк. Создайте новый код в приложении.';
  elseif($_SERVER['REQUEST_METHOD']==='POST'){
    $user=require_login(); csrf_verify();
    $st=db()->prepare("UPDATE external_app_devices SET user_id=?,status='approved',approved_at=NOW() WHERE id=? AND status='pending' AND expires_at>NOW()");$st->execute([(int)$user['id'],(int)$device['id']]);
    $ok=$st->rowCount()===1; if($ok && $device['app']==='msx' && !empty($device['client_id'])) { $raw=bin2hex(random_bytes(32)); db()->prepare("INSERT INTO external_app_tokens(user_id,app,token_hash,device_name,client_id) VALUES(?,'msx',?,?,?)")->execute([(int)$user['id'],hash('sha256',$raw),$device['device_name'],$device['client_id']]); } $message=$ok?'Устройство подключено. Вернитесь в приложение.':'Код уже использован или истёк.';
  }
}
if(!$ok && $_SERVER['REQUEST_METHOD']!=='POST'){
  $user=current_user();
  if(!$user && $code!=='') { $_SESSION['login_next']='/integrations/authorize.php?code='.rawurlencode($code); }
}
?><!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Подключение устройства · StreamLive</title>
<style>body{margin:0;background:#0b1220;color:#f4f7ff;font:16px system-ui;min-height:100vh;display:grid;place-items:center}.card{width:min(440px,calc(100% - 36px));box-sizing:border-box;background:#17243d;border:1px solid #344766;border-radius:20px;padding:28px;box-shadow:0 20px 70px #0008}h1{font-size:24px;margin:0 0 12px}p{color:#c4d0e3;line-height:1.5}.code{font-size:28px;letter-spacing:4px;font-weight:800;text-align:center;padding:15px;background:#0b1220;border-radius:12px;margin:18px 0}button,a.btn{display:block;width:100%;box-sizing:border-box;border:0;border-radius:12px;background:#2563eb;color:white;text-align:center;padding:14px;font-weight:700;text-decoration:none;cursor:pointer}input{width:100%;box-sizing:border-box;background:#0b1220;color:white;border:1px solid #405575;border-radius:10px;padding:13px;font-size:20px;letter-spacing:3px;text-align:center;margin:10px 0}</style>
<div class="card"><h1>Подключение StreamLive</h1><p><?=htmlspecialchars($message,ENT_QUOTES,'UTF-8')?></p>
<?php if($ok): ?><p>Авторизация завершена. Можно закрыть эту страницу.</p>
<?php else: ?><form method="post"><input name="code" maxlength="9" value="<?=htmlspecialchars($code,ENT_QUOTES,'UTF-8')?>" placeholder="XXXX-XXXX" required><?php if(current_user()): ?><?=csrf_field()?> <button type="submit">Разрешить доступ</button><?php else: ?><a class="btn" href="/auth/login.php?next=<?=rawurlencode('/integrations/authorize.php?code='.$code)?>">Войти в StreamLive</a><?php endif; ?></form><p><small>Код действует 10 минут. Никому не сообщайте его, кроме страницы подключения StreamLive.</small></p><?php endif; ?></div></html>
