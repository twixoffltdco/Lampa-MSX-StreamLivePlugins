<?php
require_once dirname(__DIR__).'/shared/api.php';
$base='https://'.($_SERVER['HTTP_HOST']??'');
$client=trim((string)($_GET['client_id']??''));
if($client===''||strlen($client)>100||!preg_match('/^[A-Za-z0-9._:-]+$/',$client)){
  sl_ext_json(['headline'=>'StreamLive','menu'=>[['label'=>'Ошибка устройства','data'=>$base.'/integrations/msx/connect.php']]]);
}
$connected=(bool)sl_ext_msx_user();
if(!$connected){
  sl_ext_json(['headline'=>'StreamLive','menu'=>[
    ['label'=>'Подключить аккаунт','icon'=>'user','data'=>$base.'/integrations/msx/connect.php?client_id='.rawurlencode($client)],
    ['label'=>'Обновить','icon'=>'reload','data'=>$base.'/integrations/msx/menu.php?client_id='.rawurlencode($client)]
  ]]);
}
sl_ext_json(['headline'=>'StreamLive','menu'=>[
  ['label'=>'Все каналы','icon'=>'live','data'=>$base.'/integrations/msx/content.php?client_id='.rawurlencode($client)],
  ['label'=>'Избранное','icon'=>'favorite','data'=>$base.'/integrations/msx/content.php?view=favorites&client_id='.rawurlencode($client)],
  ['label'=>'Профиль','icon'=>'user','data'=>$base.'/integrations/msx/profile.php?client_id='.rawurlencode($client)]
]]);
