<?php
// Центрированное окно-приглашение для подключения TV-оболочек.
$__slScheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') ? 'https' : 'http';
$__slHost = preg_replace('/[^A-Za-z0-9.:-]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
$__slRoot = $__slScheme . '://' . ($__slHost ?: 'localhost');
$__slLampa = $__slRoot . '/integrations/lampa/plugin.js';
$__slMsx = $__slRoot . '/integrations/msx/start.json';
?>
<div class="sl-tv-overlay" id="sl-tv-overlay" role="dialog" aria-modal="true" aria-labelledby="sl-tv-title">
  <div class="sl-tv-modal">
    <button type="button" class="sl-tv-close" id="sl-tv-close" aria-label="Закрыть">×</button>
    <div class="sl-tv-kicker">STREAMLIVE · ДЛЯ SMART TV</div>
    <h2 id="sl-tv-title">Смотри StreamLive в любимой TV-оболочке</h2>
    <p class="sl-tv-lead">Выбери приложение, которое установлено на телевизоре. Покажем адрес и короткую инструкцию подключения.</p>
    <div class="sl-tv-choice-grid">
      <button type="button" class="sl-tv-choice" data-sl-open="lampa"><span class="sl-tv-icon">▶</span><strong>Lampa</strong><small>Отдельный раздел StreamLive</small></button>
      <button type="button" class="sl-tv-choice" data-sl-open="msx"><span class="sl-tv-icon">▣</span><strong>Media Station X</strong><small>Собственное меню StreamLive</small></button>
    </div>
    <div class="sl-tv-details" id="sl-tv-lampa" hidden>
      <h3>Подключение Lampa</h3>
      <ol><li>Открой Lampa на телевизоре.</li><li>В твоей сборке должен быть доступен способ добавления стороннего плагина. Названия меню зависят от сборки Lampa.</li><li>Добавь адрес ниже и перезапусти приложение. После успешной загрузки появится отдельный пункт StreamLive.</li></ol>
      <code><?= htmlspecialchars($__slLampa, ENT_QUOTES, 'UTF-8') ?></code>
      <button type="button" class="sl-tv-copy" data-copy="<?= htmlspecialchars($__slLampa, ENT_QUOTES, 'UTF-8') ?>">Скопировать адрес плагина</button>
      <p class="sl-tv-warning">Если в твоей версии Lampa нет функции установки сторонних плагинов, сайт не может включить её удалённо. Нужна сборка Lampa с поддержкой расширений.</p>
    </div>
    <div class="sl-tv-details" id="sl-tv-msx" hidden>
      <h3>Подключение Media Station X</h3>
      <ol><li>Открой Media Station X.</li><li>Перейди в Settings → Start Parameter → Setup.</li><li>Вставь адрес JSON ниже, подтверди настройку и включи HTTPS Security Lock, если приложение этого требует.</li><li>Запусти меню StreamLive и подключи аккаунт по коду.</li></ol>
      <code><?= htmlspecialchars($__slMsx, ENT_QUOTES, 'UTF-8') ?></code>
      <button type="button" class="sl-tv-copy" data-copy="<?= htmlspecialchars($__slMsx, ENT_QUOTES, 'UTF-8') ?>">Скопировать Start Parameter</button>
    </div>
    <p class="sl-tv-note">Важно: приложение должно разрешить добавление расширения или Start Parameter. Обычный сайт не может установить его скрытно без подтверждения оболочки.</p>
  </div>
</div>
<style>
.sl-tv-overlay{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;padding:22px;background:rgba(2,7,16,.82);backdrop-filter:blur(9px);-webkit-backdrop-filter:blur(9px)}
.sl-tv-overlay[hidden]{display:none!important}.sl-tv-modal{position:relative;width:min(900px,100%);max-height:min(90vh,900px);overflow:auto;padding:clamp(24px,4vw,46px);border:1px solid rgba(100,231,201,.55);border-radius:26px;background:radial-gradient(90% 120% at 0 0,rgba(32,185,149,.26),transparent 60%),linear-gradient(145deg,#17243b,#071321);box-shadow:0 30px 110px #000c;color:#f7fbff;text-align:center;font-family:Inter,system-ui,sans-serif}
.sl-tv-close{position:absolute;right:15px;top:10px;width:42px;height:42px;border:1px solid #52677d;border-radius:50%;background:#0c1929;color:#fff;font-size:30px;line-height:1;cursor:pointer}.sl-tv-kicker{font-size:12px;font-weight:900;letter-spacing:.17em;color:#80e8cd}.sl-tv-modal h2{max-width:720px;margin:14px auto;font-size:clamp(27px,4vw,42px);line-height:1.12;font-weight:800}.sl-tv-lead{max-width:670px;margin:0 auto 26px;color:#d0dbea;line-height:1.65}.sl-tv-choice-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;max-width:720px;margin:0 auto}.sl-tv-choice{min-height:155px;border:1px solid #55738b;border-radius:18px;background:linear-gradient(145deg,#203753,#101e30);color:#fff;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:9px;transition:transform .18s,border-color .18s}.sl-tv-choice:hover,.sl-tv-choice:focus{transform:translateY(-3px);border-color:#56e2bf;outline:2px solid #56e2bf55}.sl-tv-icon{font-size:36px;color:#80e8cd}.sl-tv-choice strong{font-size:24px}.sl-tv-choice small{font-size:13px;color:#c3d1df}.sl-tv-details{max-width:720px;margin:22px auto 0;padding:22px;text-align:left;border:1px solid #405a70;border-radius:17px;background:#0b1929}.sl-tv-details h3{font-size:22px;margin:0 0 12px}.sl-tv-details ol{padding-left:23px;color:#d7e0ec;line-height:1.7}.sl-tv-details code{display:block;overflow-wrap:anywhere;color:#9ee9d5;font-size:13px;background:#06101d;padding:13px;border-radius:9px;margin:14px 0}.sl-tv-copy{border:0;border-radius:10px;padding:12px 17px;background:#20b995;color:#06231d;font-weight:900;cursor:pointer}.sl-tv-warning{color:#ffd28b;font-size:13px;line-height:1.55;margin-top:14px}.sl-tv-note{font-size:12px;color:#aebbd0;line-height:1.6;margin:22px auto 0;max-width:720px}
@media(max-width:620px){.sl-tv-overlay{padding:10px}.sl-tv-modal{padding:52px 17px 22px;border-radius:18px}.sl-tv-choice-grid{grid-template-columns:1fr}.sl-tv-choice{min-height:112px}.sl-tv-details{padding:16px}}
</style>
<script>
(function(){
 var overlay=document.getElementById('sl-tv-overlay'); if(!overlay)return;
 function open(){overlay.hidden=false;document.body.style.overflow='hidden';}
 function close(){overlay.hidden=true;document.body.style.overflow='';}
 document.getElementById('sl-tv-close').addEventListener('click',close);
 overlay.addEventListener('click',function(e){if(e.target===overlay)close();});
 document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!overlay.hidden)close();});
 document.querySelectorAll('[data-sl-open]').forEach(function(btn){btn.addEventListener('click',function(){var id='sl-tv-'+btn.getAttribute('data-sl-open');document.querySelectorAll('.sl-tv-details').forEach(function(p){p.hidden=p.id!==id;});});});
 document.querySelectorAll('.sl-tv-copy').forEach(function(btn){btn.addEventListener('click',function(){var value=btn.getAttribute('data-copy')||'';var done=function(){var old=btn.textContent;btn.textContent='Скопировано';setTimeout(function(){btn.textContent=old;},1600);};if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(value).then(done).catch(function(){fallback(value,done);});}else fallback(value,done);});});
 function fallback(value,done){var a=document.createElement('textarea');a.value=value;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();try{document.execCommand('copy');done();}catch(e){}a.remove();}
 // Show the central banner on every visit until the visitor closes it.
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',open);else open();
})();
</script>
