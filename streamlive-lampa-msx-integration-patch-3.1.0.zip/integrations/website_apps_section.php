<?php
// Visible website section for adding StreamLive to native Lampa / Media Station X apps.
$__slScheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') ? 'https' : 'http';
$__slHost = preg_replace('/[^A-Za-z0-9.:-]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
$__slRoot = $__slScheme . '://' . ($__slHost ?: 'localhost');
$__slLampa = $__slRoot . '/integrations/lampa/plugin.js';
$__slMsx = $__slRoot . '/integrations/msx/start.json';
?>
<section id="streamlive-tv-apps" class="sl-tv-apps" aria-labelledby="sl-tv-apps-title">
  <div class="sl-tv-apps-inner">
    <div class="sl-tv-apps-kicker">STREAMLIVE · TV И МЕДИАПРИЛОЖЕНИЯ</div>
    <h2 id="sl-tv-apps-title">Смотри StreamLive в Lampa и Media Station X</h2>
    <p class="sl-tv-apps-lead">Не веб-страница и не M3U-плейлист: отдельный раздел StreamLive внутри интерфейса медиаприложения.</p>
    <div class="sl-tv-apps-grid">
      <article class="sl-tv-app-card">
        <div class="sl-tv-app-name">Lampa</div>
        <p>В Lampa откройте «Настройки → Расширения» и добавьте адрес плагина. После загрузки в меню появится StreamLive.</p>
        <code><?= htmlspecialchars($__slLampa, ENT_QUOTES, 'UTF-8') ?></code>
        <button type="button" class="sl-tv-copy" data-copy="<?= htmlspecialchars($__slLampa, ENT_QUOTES, 'UTF-8') ?>">Скопировать адрес плагина</button>
      </article>
      <article class="sl-tv-app-card">
        <div class="sl-tv-app-name">Media Station X</div>
        <p>В MSX откройте Setup / Start Parameter и укажите адрес JSON-конфигурации ниже. Требуется HTTPS.</p>
        <code><?= htmlspecialchars($__slMsx, ENT_QUOTES, 'UTF-8') ?></code>
        <button type="button" class="sl-tv-copy" data-copy="<?= htmlspecialchars($__slMsx, ENT_QUOTES, 'UTF-8') ?>">Скопировать Start Parameter</button>
      </article>
    </div>
    <div class="sl-tv-app-note">После добавления откройте StreamLive прямо в Lampa или Media Station X и подключите аккаунт кодом. Кнопки копируют адреса для настроек приложений — они не запускают установку через браузер.</div>
  </div>
</section>
<style>
.sl-tv-apps{padding:clamp(28px,5vw,58px) 20px;margin:48px auto;max-width:1152px;color:var(--foreground,#f7f8fc)}.sl-tv-apps-inner{padding:clamp(24px,4vw,44px);border:1px solid color-mix(in oklab,var(--primary,#63e6be) 38%,#344054);border-radius:24px;background:radial-gradient(100% 130% at 0% 0%,rgba(42,190,160,.18),transparent 55%),linear-gradient(145deg,#17243b,#0b1220);box-shadow:0 22px 70px #0005;text-align:center}.sl-tv-apps-kicker{font-size:11px;font-weight:800;letter-spacing:.16em;color:#8cebd4}.sl-tv-apps h2{font-size:clamp(25px,4vw,38px);line-height:1.15;margin:14px auto;max-width:800px}.sl-tv-apps-lead{color:#c3cee0;max-width:720px;margin:0 auto 26px;line-height:1.6}.sl-tv-apps-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;text-align:left}.sl-tv-app-card{padding:22px;border:1px solid #3a4c67;border-radius:16px;background:#101b2dcc;min-width:0}.sl-tv-app-name{font-size:22px;font-weight:800;color:#fff}.sl-tv-app-card p{color:#c3cee0;line-height:1.55;min-height:74px}.sl-tv-app-card code{display:block;overflow-wrap:anywhere;color:#9ee9d5;font-size:12px;background:#08111f;padding:12px;border-radius:9px;margin:14px 0}.sl-tv-copy{border:0;border-radius:10px;padding:12px 16px;background:#20b995;color:#06231d;font-weight:800;cursor:pointer}.sl-tv-app-note{font-size:12px;color:#aebbd0;line-height:1.5;margin:20px auto 0;max-width:820px}@media(max-width:680px){.sl-tv-apps-grid{grid-template-columns:1fr}.sl-tv-app-card p{min-height:0}}
</style>
<script>
(function(){document.querySelectorAll('.sl-tv-copy').forEach(function(b){b.addEventListener('click',function(){var value=b.getAttribute('data-copy')||'';function done(){var old=b.textContent;b.textContent='Скопировано';setTimeout(function(){b.textContent=old},1800)}if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(value).then(done).catch(function(){fallback()})}else fallback();function fallback(){var t=document.createElement('textarea');t.value=value;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();try{document.execCommand('copy');done()}catch(e){b.textContent='Скопируйте адрес вручную'}t.remove()}})})})();
</script>
