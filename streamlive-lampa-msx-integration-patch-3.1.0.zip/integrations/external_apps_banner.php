<?php
// Small site-wide notice. The full centered installation guide lives on the landing page.
$__slCandidates = [(string)($_SERVER['REQUEST_URI'] ?? ''), (string)($_SERVER['PATH_INFO'] ?? ''), (string)($_SERVER['PHP_SELF'] ?? ''), (string)($_SERVER['SCRIPT_NAME'] ?? '')];
$__slExcluded = false;
foreach ($__slCandidates as $__slCandidate) {
    $__slPath = (string)(parse_url($__slCandidate, PHP_URL_PATH) ?? $__slCandidate);
    if (preg_match('~(?:^|/)(?:platforma|native|native-app)(?:/|$)~i', $__slPath)) { $__slExcluded = true; break; }
}
$__slExcluded = $__slExcluded || (($_COOKIE['sl_native_app'] ?? '') === '1') || !empty($_COOKIE['streamlive_native_app']);
if (!$__slExcluded):
?>
<div class="sl-ext-site-note"><span>StreamLive доступен в интерфейсах Lampa и Media Station X</span> <a href="/#streamlive-tv-apps">Как подключить →</a></div>
<style>.sl-ext-site-note{margin:12px auto 22px;padding:10px 16px;max-width:900px;text-align:center;border:1px solid #315b59;border-radius:12px;background:rgba(22,185,149,.09);color:var(--text,#ddd);font:600 13px/1.5 system-ui,sans-serif}.sl-ext-site-note a{color:#20b995;text-decoration:underline;margin-left:8px}</style>
<?php endif; ?>
