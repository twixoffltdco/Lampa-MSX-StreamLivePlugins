<?php
/** StreamLive external-app integration API. Device-token auth; no password collection in TV apps. */
require_once dirname(__DIR__, 2) . '/includes/functions.php';
require_once dirname(__DIR__, 2) . '/includes/auth.php';
require_once dirname(__DIR__, 2) . '/includes/paid_access.php';

function sl_ext_schema(): void {
  static $done=false; if($done)return; $done=true;
  db()->exec("CREATE TABLE IF NOT EXISTS external_app_devices (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    app VARCHAR(24) NOT NULL,
    device_code_hash CHAR(64) NOT NULL,
    user_code_hash CHAR(64) NOT NULL,
    user_id INT NULL,
    access_token_hash CHAR(64) NULL,
    status ENUM('pending','approved','denied','expired') NOT NULL DEFAULT 'pending',
    token_issued TINYINT(1) NOT NULL DEFAULT 0,
    device_name VARCHAR(120) DEFAULT NULL,
    client_id VARCHAR(100) DEFAULT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approved_at DATETIME NULL,
    INDEX idx_ext_user_code(user_code_hash), INDEX idx_ext_device_code(device_code_hash),
    INDEX idx_ext_user(user_id), CONSTRAINT fk_ext_device_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  try { db()->exec('ALTER TABLE external_app_devices ADD COLUMN client_id VARCHAR(100) DEFAULT NULL'); } catch (Throwable $e) {}
  db()->exec("CREATE TABLE IF NOT EXISTS external_app_tokens (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    app VARCHAR(24) NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    device_name VARCHAR(120) DEFAULT NULL,
    client_id VARCHAR(100) DEFAULT NULL,
    last_used_at DATETIME DEFAULT NULL,
    revoked_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ext_token_user(user_id),
    CONSTRAINT fk_ext_token_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  try { db()->exec("ALTER TABLE external_app_tokens ADD COLUMN client_id VARCHAR(100) DEFAULT NULL"); } catch (Throwable $e) {}
}
function sl_ext_headers(): void {
  header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store, private');
  header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: no-referrer');
  header('Access-Control-Allow-Origin: *'); header('Access-Control-Allow-Methods: GET, POST, OPTIONS'); header('Access-Control-Allow-Headers: Authorization, Content-Type');
  if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }
}
function sl_ext_json($data,int $status=200): void { sl_ext_headers(); http_response_code($status); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function sl_ext_input(): array { $v=json_decode(file_get_contents('php://input'),true); return is_array($v)?$v:$_POST; }
function sl_ext_app(string $app): string { return in_array($app,['lampa','msx'],true)?$app:'unknown'; }
function sl_ext_token_user(): ?array {
  sl_ext_schema(); $h=function_exists('getallheaders')?getallheaders():[]; $auth=(string)($h['Authorization']??$h['authorization']??$_SERVER['HTTP_AUTHORIZATION']??'');
  if(!preg_match('/^Bearer\s+([A-Fa-f0-9]{64})$/',$auth,$m)) return null;
  $hash=hash('sha256',$m[1]);
  $st=db()->prepare("SELECT t.id token_id,u.* FROM external_app_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.revoked_at IS NULL AND (u.is_banned IS NULL OR u.is_banned=0) LIMIT 1");
  $st->execute([$hash]); $u=$st->fetch(); if(!$u)return null;
  db()->prepare('UPDATE external_app_tokens SET last_used_at=NOW() WHERE id=?')->execute([(int)$u['token_id']]); unset($u['token_id']); return $u;
}
function sl_ext_require_token(): array { $u=sl_ext_token_user(); if(!$u)sl_ext_json(['ok'=>false,'error'=>'auth_required'],401); return $u; }
function sl_ext_msx_user(): ?array {
  sl_ext_schema(); $client=trim((string)($_GET['client_id']??'')); if($client===''||strlen($client)>100||!preg_match('/^[A-Za-z0-9._:-]+$/',$client))return null;
  $st=db()->prepare("SELECT u.* FROM external_app_tokens t JOIN users u ON u.id=t.user_id WHERE t.app='msx' AND t.client_id=? AND t.revoked_at IS NULL AND (u.is_banned IS NULL OR u.is_banned=0) ORDER BY t.id DESC LIMIT 1");$st->execute([$client]);return $st->fetch()?:null;
}
function sl_ext_catalog(): array {
  paid_ensure_schema();
  $sql="SELECT c.id,c.slug,c.title,c.description,c.type,c.logo_url,c.owner_id,c.views,c.paid_content,c.paid_content_locked,c.is_broadcast_paused
        FROM channels c WHERE c.status='approved' AND COALESCE(c.paid_content,0)=0 AND COALESCE(c.paid_content_locked,0)=0 ORDER BY c.views DESC,c.title ASC LIMIT 500";
  $rows=db()->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[]; $out=[];
  foreach($rows as $c){
    if(!empty($c['paid_content'])||!empty($c['paid_content_locked'])||!empty($c['is_broadcast_paused']))continue;
    try{$s=resolve_active_source($c);}catch(Throwable $e){$s=null;}
    if(!$s||empty($s['url']))continue; $type=strtolower((string)($s['type']??''));
    if(!in_array($type,['mp4','m3u8'],true))continue; $url=trim((string)$s['url']);
    if(!filter_var($url,FILTER_VALIDATE_URL)||stripos($url,'https://')!==0)continue;
    $out[]=['id'=>(int)$c['id'],'slug'=>(string)$c['slug'],'title'=>(string)$c['title'],'description'=>(string)($c['description']??''),'category'=>(string)($c['type']??'tv'),'logo'=>(string)($c['logo_url']??''),'stream'=>$url,'format'=>$type==='mp4'?'mp4':'hls'];
  } return $out;
}
sl_ext_schema();
