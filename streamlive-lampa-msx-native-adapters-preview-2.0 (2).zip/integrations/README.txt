StreamLive External Apps Integration
Build: 2.0 preview
Adapters: Lampa plugin (native Activity/Component UI), Media Station X Start/Menu/Content API.
Backend: shared read-only public catalog adapter using the real StreamLive v28.53 channel/source functions.
