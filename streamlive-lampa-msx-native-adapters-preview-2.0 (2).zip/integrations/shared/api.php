<?php
/** StreamLive external-app API. Only approved, free, unlocked channels are exposed. */
require_once dirname(__DIR__, 2) . '/includes/functions.php';
require_once dirname(__DIR__, 2) . '/includes/auth.php';
require_once dirname(__DIR__, 2) . '/includes/paid_access.php';

function sl_ext_headers(): void {
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store, private');
  header('X-Content-Type-Options: nosniff');
  header('Referrer-Policy: no-referrer');
  // Public catalog is read-only. No credentialed wildcard CORS is enabled.
  $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
  if ($origin !== '' && preg_match('~^https://([a-z0-9-]+\.)*streamlive\.[a-z]{2,}$~i', $origin)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
  }
}
function sl_ext_catalog(): array {
  paid_ensure_schema();
  $sql = "SELECT c.id,c.slug,c.title,c.description,c.type,c.logo_url,c.default_source_id,c.owner_id,c.views,c.paid_content,c.paid_content_locked,c.is_broadcast_paused
          FROM channels c
          WHERE c.status='approved' AND COALESCE(c.paid_content,0)=0 AND COALESCE(c.paid_content_locked,0)=0
          ORDER BY c.views DESC,c.title ASC LIMIT 500";
  $rows = db()->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
  $out=[];
  foreach ($rows as $c) {
    if (!empty($c['paid_content']) || !empty($c['paid_content_locked']) || !empty($c['is_broadcast_paused'])) continue;
    try { $s=resolve_active_source($c); } catch (Throwable $e) { $s=null; }
    if (!$s || empty($s['url'])) continue;
    $type=strtolower((string)($s['type'] ?? ''));
    if (!in_array($type,['mp4','m3u8'],true)) continue;
    $url=trim((string)$s['url']);
    if (!filter_var($url,FILTER_VALIDATE_URL) || stripos($url,'https://')!==0) continue;
    $out[]=[
      'id'=>(int)$c['id'], 'slug'=>(string)$c['slug'], 'title'=>(string)$c['title'],
      'description'=>(string)($c['description']??''), 'category'=>(string)($c['type']??'tv'),
      'logo'=>(string)($c['logo_url']??''), 'stream'=>$url, 'format'=>$type==='mp4'?'mp4':'hls'
    ];
  }
  return $out;
}
function sl_ext_json($data): void { sl_ext_headers(); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }
