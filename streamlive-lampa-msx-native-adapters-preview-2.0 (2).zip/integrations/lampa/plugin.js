(function () {
  'use strict';
  if (window.streamlive_lampa_plugin) return;
  window.streamlive_lampa_plugin = true;
  var API = (function(){ var scripts=document.getElementsByTagName('script'); for(var i=scripts.length-1;i>=0;i--){var src=scripts[i].src||''; if(src.indexOf('/integrations/lampa/plugin.js')!==-1) return src.split('/integrations/lampa/plugin.js')[0]+'/integrations/lampa/catalog.php';} return location.protocol+'//'+location.host+'/integrations/lampa/catalog.php'; })();
  var NAME = 'StreamLive';

  function Screen(object) {
    var self=this, scroll=new Lampa.Scroll({mask:true,over:true}), net=new Lampa.Reguest(), alive=true;
    this.create=function(){
      self.activity.loader(true);
      net.get(API,function(data){
        if(!alive) return;
        self.activity.loader(false);
        var items=(data && data.items) || [];
        if(!items.length){ self.activity.empty(); return; }
        items.forEach(function(ch){
          var logo=ch.logo ? '<img class="streamlive__logo" src="'+String(ch.logo).replace(/"/g,'&quot;')+'">' : '<span class="streamlive__logo"></span>';
          var el=$('<div class="selector streamlive__item">'+logo+'<div class="streamlive__meta"><div class="streamlive__title"></div><div class="streamlive__desc"></div></div></div>');
          el.find('.streamlive__title').text(ch.title || 'Канал');
          el.find('.streamlive__desc').text(ch.description || 'Прямой эфир');
          el.on('hover:enter',function(){
            if(!ch.stream || !/^https:\/\//i.test(ch.stream)) { Lampa.Noty.show('Источник недоступен',{style:'error'}); return; }
            Lampa.Player.play({url:ch.stream,title:ch.title||NAME,is_live:true,source:'streamlive'});
          });
          scroll.append(el);
        });
      },function(){ if(alive){self.activity.loader(false);self.activity.empty();} });
      return self.render();
    };
    this.render=function(){return scroll.render();};
    this.destroy=function(){alive=false;net.clear();scroll.destroy();};
  }
  function init(){
    if(!Lampa.Component.get('streamlive_catalog')) Lampa.Component.add('streamlive_catalog',Screen);
    Lampa.Lang.add({streamlive_title:{ru:'StreamLive',en:'StreamLive'}});
    var btn=$('<li class="menu__item selector"><div class="menu__ico"><svg width="44" height="44" viewBox="0 0 44 44"><rect width="44" height="44" rx="8" fill="currentColor" opacity=".16"/><path d="M12 15h20v14H12zM17 11l5 4 5-4" fill="none" stroke="currentColor" stroke-width="2"/></svg></div><div class="menu__text">StreamLive</div></li>');
    btn.on('hover:enter',function(){Lampa.Activity.push({url:API,title:NAME,component:'streamlive_catalog',page:1});});
    $('.menu .menu__list').eq(0).append(btn);
  }
  if(window.appready) init(); else Lampa.Listener.follow('app',function(e){if(e.type==='ready')init();});
})();
