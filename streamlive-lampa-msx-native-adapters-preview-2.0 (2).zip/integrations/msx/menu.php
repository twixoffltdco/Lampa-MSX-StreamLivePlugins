<?php
require_once dirname(__DIR__).'/shared/api.php';
$base=(function(){ $https=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||($_SERVER['HTTP_X_FORWARDED_PROTO']??'')==='https'; return ($https?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost'); })();
$items=[
 ['title'=>'Все каналы','action'=>$base.'/integrations/msx/content.php','type'=>'list'],
 ['title'=>'Открыть StreamLive','action'=>$base.'/channels.php','type'=>'link']
];
sl_ext_json(['headline'=>'StreamLive','menu'=>$items]);
