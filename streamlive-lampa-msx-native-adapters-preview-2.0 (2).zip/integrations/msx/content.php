<?php
require_once dirname(__DIR__).'/shared/api.php';
$base=(function(){ $https=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||($_SERVER['HTTP_X_FORWARDED_PROTO']??'')==='https'; return ($https?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost'); })();
$items=[];
foreach(sl_ext_catalog() as $c){
  $items[]=['title'=>$c['title'],'image'=>$c['logo'],'description'=>$c['description'],'action'=>$c['stream'],'type'=>'video'];
}
sl_ext_json(['type'=>'content','headline'=>'StreamLive · Каналы','template'=>'poster','items'=>$items,'provider'=>['name'=>'StreamLive','icon'=>'https://'.($_SERVER['HTTP_HOST']??'localhost').'/favicon.ico']]);
