StreamLive MSX fix 3.5.0

Распакуйте содержимое патча в корневую папку StreamLive (рядом с index.php).
Должны появиться:
  /msx/start.json
  /msx/INSTALL.txt
Также обновится:
  /integrations/msx/start.json

В Media Station X в Start Parameter -> Setup вводится только домен без https:// и без /.
MSX автоматически запрашивает https://ВАШ-ДОМЕН/msx/start.json.
Для HTTPS включите Security Lock.
