<?php
require_once dirname(__DIR__).'/shared/api.php';
$u=sl_ext_msx_user();$input=sl_ext_input();$data=$input['data']??$input;if(is_string($data)){$decoded=json_decode($data,true);if(is_array($decoded))$data=$decoded;}
if(!$u){sl_ext_headers();http_response_code(200);echo json_encode(['response'=>['data'=>['action'=>'error:Сначала подключите аккаунт StreamLive']]],JSON_UNESCAPED_UNICODE);exit;}
$id=(int)($data['channel_id']??0);$st=db()->prepare("SELECT id FROM channels WHERE id=? AND status='approved' AND COALESCE(paid_content,0)=0 AND COALESCE(paid_content_locked,0)=0 AND COALESCE(is_broadcast_paused,0)=0");$st->execute([$id]);
if(!$st->fetch()){$action='error:Канал недоступен';}else{$st=db()->prepare('SELECT id FROM favorites WHERE user_id=? AND channel_id=?');$st->execute([(int)$u['id'],$id]);if($st->fetch()){db()->prepare('DELETE FROM favorites WHERE user_id=? AND channel_id=?')->execute([(int)$u['id'],$id]);$action='success:Удалено из избранного';}else{db()->prepare('INSERT IGNORE INTO favorites(user_id,channel_id) VALUES(?,?)')->execute([(int)$u['id'],$id]);$action='success:Добавлено в избранное';}}
sl_ext_headers();echo json_encode(['response'=>['data'=>['action'=>$action]]],JSON_UNESCAPED_UNICODE);
